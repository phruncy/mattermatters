import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shiffman.box2d.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.contacts.*; 
import java.util.HashMap; 
import java.util.Collections; 
import ddf.minim.*; 
import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class matter_matters extends PApplet {

/**
 * This class managed the Screen the player sees when the game is lost.
 * To make it more fun to watch, some particle clash is happening in the 
 * background.
 */
public class LostScreen extends SceneContent
{
    private int _background = jsonLoader.loadColorFromConfig("lost");
    private PFont font;
    private int particleNumber = 100;
    private float displayedScore;
    private int fontColor;
    private String title = jsonLoader.loadText("lost", "title");
    private String message = jsonLoader.loadText("lost", "message");

    public LostScreen()
    {
        // Telegrama font by Yamaoka Yashuhiro, 1992
        font = createFont("fonts/telegrama_raw.otf", 20);
        textFont(font);
        fontColor = jsonLoader.loadColorFromConfig("font");
        displayedScore = scoreManager.getCurrent();
        // initiate some lovely particles and add them to active objects
        for (int i = 0; i < particleNumber; i++) {
            AntiMatterParticle left = new AntiMatterParticle(
                -20 + random(-3, 3), 
                height / 2 + random(-3, 3), 
                3, new Vec2(1, 0), 600
            );
            AntiMatterParticle right = new AntiMatterParticle(
                width + 20 - random(-3, 3),
                height / 2 + random(-3, 3),
                3, new Vec2(-1, 0), 600
            );
            activeObjects.addObject(left);
            activeObjects.addObject(right);
        }
    }

    public void update() {
        activeObjects.update();
    }

    public void display()
    {
        background(_background);
        activeObjects.display();
        fill(fontColor);
        textSize(70);
        textAlign(CENTER, CENTER);
        text(title, width / 2, 100);
        textSize(35);
        text("Your score is: " + displayedScore, width / 2, 250);
        text(message, width / 2, height - 120);
    }
    /**
     * Destroy all GameObjects from the Scene
     */
    protected void removeExternalLibraryReferences() {
        activeObjects.clearAllObjects();
    }
}
/**
 * A wrapper around all GameObjects that are currently existing in the program. 
 * Provides public functions that manage all behaviour of game objects that is * unrelated to the active scene * they are displayed in, 
 * namely update and display
 */
public class ActiveGameObjectsManager 
{
    /**
     * All objects that are active and are still alive.
     */
    private ArrayList<GameObject> activeGameObjects = new ArrayList<GameObject>();

    /**
     * This List holds a reference to all ForceEmitters
     */
    private ArrayList<ForceEmitter> emitters = new ArrayList<ForceEmitter>(); 

    /**
     * This list holds references to all PlayerParticle Objects that are in the activeGameObjects List
     */
    private ArrayList<PlayerParticle> playerParticles = new ArrayList<PlayerParticle>();

    /**
     * a reference to a player Object from ActiveGameObjects 
     */
    private PlayerObject player;

    /**
     * Contains all Objects that have been given 
     * free for deletion during update(). Gets cleared once every frame.
     */
    private ArrayList<GameObject> deletables = new ArrayList<GameObject>();

     /**
     * Update all active Objects. Check if any objects have left 
     * the screen and mark them as destroyed. Destroyed objects are moved to 
     * deletables. Then perforems update tasks on specific types of objects 
     * such as player particles or emitters
     */
    public void update() {
        clearDeletables();

        for (GameObject o: activeGameObjects) {
            o.update();
            applyEmitterForces(o);
        }
        // player particle specific task
        for (PlayerParticle p: playerParticles) {
            p.applyPlayerAttraction(player);
        }
        //check for deletion
        for (int i = 0; i < activeGameObjects.size(); i++) {
            GameObject o = activeGameObjects.get(i);
            if (!o.checkAliveness()) {
                assert(!deletables.contains(o));
                deletables.add(o);
                activeGameObjects.remove(o);
                if (emitters.contains(o)) {
                    emitters.remove(o);
                }
                if (playerParticles.contains(o)) {
                    playerParticles.remove(o);
                }
                i--;
            }
        }
    }

    /**
     * Displays all elements from activeGameObjects
     */
    public void display() 
    {
        for (GameObject o: activeGameObjects) {
            o.display();
        }
    }

    /**
     * Adds a GameObject to activeGameObjects
     * 
     * @param The Game Object to be added
     */
    public void addObject(GameObject o) {
        activeGameObjects.add(o);
    }

    /**
     * Adds a Force Emitter that is already in Game object to the list of emitters;
     */
    public void addEmitter(ForceEmitter emitter) 
    {
        assert (activeGameObjects.contains(emitter));
        emitters.add(emitter);
    }

    /**
     * sets the player Object
     */
    public void setPlayer(PlayerObject p) 
    {
        assert (activeGameObjects.contains(p));
        player = p;
    }

    /**
     * Adds an entry to the list of player particles
     */
    public void addPlayerParticle(PlayerParticle particle) {
        assert (activeGameObjects.contains(particle));
        playerParticles.add(particle);
    }

    /**
     * @return true if at least one Player particle is among the 
     * active game objects, false otherwise 
     */
    public boolean getParticleAliveness() {
        boolean statement = (playerParticles.size() > 0);
        return statement;
    }

    /**
     * calculates and applies all Forces from the emitters on a target
     *
     * @param target The GameObject on which the force is applied
     */
    private void applyEmitterForces(GameObject target) {
        for (ForceEmitter e: emitters) {
            Vec2 force = e.emitForce(target);
            target.applyForce(force);
        }
    }

    public void clearAllObjects()
    {
        for (GameObject o: activeGameObjects) {
            o.destroy();
        }
        activeGameObjects.clear();
        playerParticles.clear();
        emitters.clear();
        player = null;
    }

    /**
     * removes all Objects marked as deletable from the scene by invoking 
     * destroy() on every object in deletables and then clearing the list.
     * called once every frame at the very beginning of the update() method
     */
    private void clearDeletables() 
    {
        for (GameObject o: deletables) {
            assert(!o.isDeleted());
            o.destroy();
        }
        deletables.clear();
    }
}    
/**
 * Manages the appearance of a bunch of AntiMatterParticle objects.
 * The event only controls their initial spawn and velocity, but not the 
 * lifetime.
 */
public class AntiMatterEvent extends GameObjectEvent
{
    /**
     * Contains all managed AntiMatterParticles
     */
    private ArrayList<Particle> antiMatter;

    public AntiMatterEvent(String id, Slot slot)
    {
        super(id, slot);
    }

    protected void _update() {}
    public void markDeletables() {}

    /**
     * adds all managed Particles to activeGameObjects
     */
    public void addManagedObjectsToActiveObjects() 
    {
        for (Particle particle: antiMatter) {
            activeObjects.addObject(particle);
        }
    }

    protected void createManagedGameObject() 
    {
        // initiate List
        antiMatter = new ArrayList<Particle>();
        int counter = jsonLoader.loadIntFromEvent(eventJson, "counter");
        for (int i = 0; i < counter; i++) {
            // load event data
            float radius = jsonLoader.loadFloatFromEvent(eventJson, "radius");
            float speed = jsonLoader.loadFloatFromEvent(eventJson, "speed");
            String coordinate = jsonLoader.loadStringFromEvent(eventJson, "slotCoordinate");
            float x, y;
            // getting the spawning location and initial velocity
            // determine from which of the four sides the object will spawn
            if (coordinate == null) {
                // default values in case of errors
                x = -20 + random(-5, 5);
                y = -20 + random(-5, 5);
            }
            if (coordinate.equals("x")) {
                //object will spawn from top or bottom of the screen around the x position ot the slot + some variance
                x = _slot.position.x + random(-5, 5);
                // determines wheter it will top or bottom with 50% chance
                if (Math.random() < 0.5f) {
                    y = - 20 + random(-5, 5);
                } else {
                    y = height + 20 + random(-5, 5);
                }
            }
            else if (coordinate.equals("y")) {
                // object will spawn from left or right of the screen at the height of the slot position + some variance
                y = _slot.position.y + random(-5, 5);
                // determine wheter it will be left or right with 50% chance
                if (Math.random() < 0.5f) {
                    x = - 20 + random(-5, 5);
                } else {
                    x = height + 20 + random(-5, 5);
                }
            } else {
                //if there is an error in the json data values these default values are assigned
                x = -20 + random(-5, 5);
                y = -20 + random(-5, 5);
            }
            Vec2 position = box2d.coordPixelsToWorld(x, y);
            Vec2 direction = computeDirection(position);
            // add Particle
            AntiMatterParticle particle = new AntiMatterParticle(
                x, y, radius, direction, speed
            );
            assert(particle != null);
            antiMatter.add(particle);
        }    
    };
    
    /**
     * Calculates and return a vector that is directed at the center of the screen.
     * @param position The position of the object in the box2d world for which the direction is calculated
     * @return a Vector directed at the center of the screen
     */
    private Vec2 computeDirection(Vec2 position) 
    {
        Vec2 direction = box2d.coordPixelsToWorld(width / 2, height / 2);
        direction.subLocal(position);
        direction.normalize();
        return direction;
    }
}
/**
 * A class of particles that erase Player particles on collision and get erased * upon collision with other rigid game objects
 * move through space without damping
 */
public class AntiMatterParticle extends Particle implements OnCollisionEnter
{
    /**
     * @param posX x coordinate of center in pixels
     * @param posY y coordinate of center in pixels
     * @param radius the particle's radius
     * @param initDirection the direction of the initial velocity as Vec2
     */
    public AntiMatterParticle(float posX, float posY, float radius, Vec2 initDirection, float speed)
    {
        super(posX, posY, radius);
        _color = jsonLoader.loadColorFromConfig("antiMatterParticle");
        Vec2 velocity = initDirection.clone();
        float multiplier = jsonLoader.loadFloatFromConfig("antiMatterParticle", "initVelocity");
        initDirection.normalize();
        velocity.mulLocal(speed);
        // set initial velocity
        body.applyLinearImpulse(velocity, body.getWorldCenter(), true);
    }

    /**
     * invoked in Collision ContactBegin Callback
     *
     * @param collider the other object involved in the collision
     */
    public void onCollisionEnter(GameObject collider)
    {
        if (collider instanceof PlayerParticle) {
            collider.setDead();
            setDead();
        }
    }
}
/**
 * a special kind of attractor that causes the destruction of objects colliding * with it. 
 */
public class BlackHole extends CosmicBody implements OnCollisionEnter
{
    /**
     * @param posX x-coordinate in pixels
     * @param posY y-coordinate in pixels
     * @param radius the object's radius in pixels
     * @param g strength of the attracting force
     */
    public BlackHole(float posX, float posY, float radius, float g) 
    {
        super(posX, posY, radius, false, g);
        _color = jsonLoader.loadColorFromConfig("blackHole");
    }

    /**
     * when a Black hole collides with another object, the other object is 
     * marked for deletion and will be destroyed in the next frame
     */
    public void onCollisionEnter(GameObject collider) {
        if (collider instanceof Particle) {
            collider.setDead();
        }
    }
}
/**
 * A Game Object that can eiher attract or repel other game objects
 * Cosmic bodies can only emit forces but are not subject to forces themselves
 */
public class CosmicBody extends GameObject implements ForceEmitter
{
    /**
     * If false, the object will attract other objects, if true it repels them
     */
    protected boolean isRepelling;
    
    /**
     * The objects radius in pixels
     */
    private float _radius;
    /**
     * Constant multiplier for the emitted force -> determines its strength
     */
    private float G;

    /**
     * The displaying color of the body
     */
    protected int _color = color(255);

    /**
     * @param posX x-coordinate in pixels
     * @param posY y-coordinate in pixels
     * @param radius the object's radius in pixels
     * @param mode 0 if the object is attracting, 1 if it is repelling
     * @param g strength of the attracting force
     */
    public CosmicBody(float posX, float posY, float radius, boolean mode, float g)
    {
        super(posX, posY);
        isRepelling = mode;
        G = g;

        _radius = radius;
        CircleShape shape = new CircleShape();
        float worldRadius = box2d.scalarPixelsToWorld(_radius);
        shape.m_radius = worldRadius;

        FixtureDef fixDef = new FixtureDef();
        fixDef.shape = shape;
        fixDef.friction = 0.1f;
        fixDef.restitution = 0.5f;
        fixDef.density = 10000;

        body.createFixture(fixDef);
    }

    /**
     * @override
     * displays the cosmic body as circle
     */
    public void display() 
    {
        Vec2 position = box2d.getBodyPixelCoord(body);
        push();
            noStroke();
            fill(_color);
            ellipse(position.x, position.y, _radius * 2, _radius * 2);
        pop();
    }

    /**
     * @param o the GameObject on which the force is applied
     * @return the calculated attracting or repelling force as a vector
     */
    public Vec2 emitForce(GameObject o)
    {
        float direction = isRepelling ? -1 : 1;
        Vec2 position = body.getWorldCenter();
        Vec2 oPosition = o.getBody().getWorldCenter();
        Vec2 force = position.sub(oPosition);
        float distance = force.length();
        distance = constrain(distance, 1, 5);
        float strength = (G * o.getBody().m_mass) / (distance * distance);
        force.normalize();
        force.mulLocal(strength).mulLocal(direction);
        return force;
    } 

    protected void _destroy() {}

    
    public boolean checkAliveness() 
    {
        return isAlive;
    }

    /**
     * by default, cosmic bodies are not sujected to forces and don't move 
     * either
     *
     * @value BodyType.STATIC
     */
    protected BodyType getBodyType()
    {
        return BodyType.STATIC;
    }
}
/**
 * This class is a wrapper around the spawning of a NPC CosmicBody in the Game.
 * It contains the GameObjects itself and manages the CosmicBody's behaviour in 
 * the game. Managed properties are the chance of spawning, spawning location, * the object's lifetime and values the object is initiated with. The reason  
 * for this aproach is to seperate the GameObject's behaviour within the game 
 * flow from the object logic itself and to allow for better control over the 
 * game flow.
 * Event data is loaded from the events.json.
 */
public class CosmicBodyEvent extends GameObjectEvent {

    /**
     * Reference to the Object the Event is managing
     */
    private CosmicBody cosmicBody;

    public CosmicBodyEvent(String id, Slot slot)
    {
        super(id, slot);
        _hasEmitter = true;
    }

    /**
     * creates the CosmicBody from the data given by the event json. 
     * If no Object can be created, _hasObject will be set to false 
     * and the event will be marked as expired.
     */
    protected void createManagedGameObject()
    {
        String type = jsonLoader.loadStringFromEvent(eventJson, "type");
        float radius = jsonLoader.loadFloatFromEvent(eventJson, "radius");
        float force = jsonLoader.loadFloatFromEvent(eventJson, "force");
        float posX = _slot.position.x;
        float posY = _slot.position.y;
        if (type.equals("BlackHole")) {
            cosmicBody = new BlackHole(posX, posY, radius, force);
        } else if (type.equals("Pulsar")) {
            cosmicBody = new Pulsar(posX, posY, radius, true, force);
        } else {
            _hasObject = false;
            _hasExpired = true;
        }
    }

    public void addManagedObjectsToActiveObjects()
    {
        activeObjects.addObject(cosmicBody);
    }

    public void tryAddToEmitters()
    {
        activeObjects.addEmitter(cosmicBody);
    }

    protected void _update() {}

    public void markDeletables() 
    {
        if (cosmicBody != null) {
            cosmicBody.setDead();
        }
    }
}
/**
 * Factory to produce an event of a specific type for the Game
 */
public class EventFactory {
    /**
     * @return The Event associated with the given id if the id is valid. 
     * Null if either the id or the event are invalid.
     */
    public GameObjectEvent createEvent(String id, Slot slot) {
        JSONObject eventJson = jsonLoader.loadEventById(id);
        String eventType = jsonLoader.loadStringFromEvent(eventJson, "eventType");
        switch(eventType) {
            case "CosmicBody":
                return new CosmicBodyEvent(id, slot);
            case "SpaceJunk":
                return new SpaceJunkEvent(id, slot);
            case "ForceField":
                return new ForceFieldEvent(id, slot);
            case "AntiMatter":
                return new AntiMatterEvent(id, slot);
        }
        return null;
    }
}
/**
 * implemented by all Objects that emit forces on other Objects (namely force 
 * fields and cosmic bodies)
 */
public interface ForceEmitter 
{
    /** 
     * @param o: the target object for which the force is calculated
     */
    public Vec2 emitForce(GameObject o);
}
/**
 * a class for Game Objects that mark an area where a constant force is applied 
 * to objects that are in that area
 * basically acting as a 'wind zone'
 */
public class ForceField extends GameObject implements ForceEmitter, OnCollisionEnter, OnCollisionExit
{
    private float _w;
    private float _h;
    private Vec2 _force;

    /**
     * a list of all objects that are currently in the forcefield's area
     */
    private ArrayList<GameObject> visitors; 

    /**
     * @param posX the x coordinate of the center of the area in pixels
     * @param posY the y coordinate of the center of the area in pixels
     * @param w the width of the forcefield's area
     * @param h the height of the forcefield's area
     * @param direction the direction of the forcefield's force
     * @param strength the strength of the forcefields force
     */
    public ForceField(float posX, float posY, float w, float h, Vec2 direction, float strength)
    {
        super(posX, posY);
        
        _w = w;
        _h = h;
        PolygonShape shape = new PolygonShape();
        float bodyW = box2d.scalarPixelsToWorld(_w / 2);
        float bodyH = box2d.scalarPixelsToWorld(_h / 2);
        shape.setAsBox(bodyW, bodyH);

        FixtureDef fixDef = new FixtureDef();
        fixDef.shape = shape;
        // sets the object not as rigid body but still enables collision detection
        fixDef.isSensor = true;
        body.createFixture(fixDef);

        direction.normalize();
        _force = direction.mulLocal(strength);
        visitors = new ArrayList<GameObject>();
    }

    /**
     * force it applied to all visitors in every frame
     */
    public void update()
    {
        for (GameObject visitor: visitors) {
            
            Vec2 force = emitForce(visitor);
            visitor.applyForce(force);
        }
    }

    public void display() 
    {
        Vec2 position = box2d.getBodyPixelCoord(body);
        push();
            noStroke();
            rectMode(CENTER);
            translate(position.x, position.y);
            fill(255, 25); 
            rect(0, 0, _w, _h);
        pop();
    }

    public boolean checkAliveness() 
    {
        return isAlive;
    }

    /**
     * when an object enters the forcefield's area it is added to 
     * the list of visitors
     */
    public void onCollisionEnter(GameObject collider) 
    {
        if (collider instanceof Particle) {
            visitors.add(collider);
        }
    }

    /**
     * when an object leaves the forcefield's area it is removed from the
     * list of visitors (with extra check if it was an that list in the 
     * first place), just to be sure
     */
    public void onCollisionExit(GameObject collider) 
    {
        if (visitors.contains(collider)) {
            visitors.remove(collider);
        }
    }

    protected void _destroy() {}

    /**
     * invoked by the update() method on all objects in the visitors list
     *
     * @param o the object for wich the force is calculated
     * @return the calculated force as Vec2
     */
    public Vec2 emitForce(GameObject o)
    {
        Vec2 force = new Vec2(_force.x, _force.y);
        force.mulLocal(1 / o.getBody().m_mass);
        return force;
    }

    /**
     * force fields are by default not moving and not subjected to forces
     */
    protected BodyType getBodyType()
    {
        return BodyType.STATIC;
    }
}
/**
 * Manages the Appearance of a Force Field in the Game.
 *
 * @see GameObjectEvent
 */
public class ForceFieldEvent extends GameObjectEvent
{
    protected ForceField forceField;
    
    public ForceFieldEvent(String id, Slot slot)
    {
        super(id, slot);
        _hasEmitter = true;
    }

    public void addManagedObjectsToActiveObjects()
    {
        activeObjects.addObject(forceField);
    }

    public void tryAddToEmitters()
    {
        activeObjects.addEmitter(forceField);
    }

    public void markDeletables() 
    {
        if (forceField != null) {
            forceField.setDead();
        }
    }

    protected void _update() {}

    /**
     * creates the ForceField from the data given by the event json. 
     * If no Object can be created, _hasObject will be set to false 
     * and the event will be marked as expired.
     */
    protected void createManagedGameObject()
    {
        float w = jsonLoader.loadFloatFromEvent(eventJson, "width");
        float h = jsonLoader.loadFloatFromEvent(eventJson, "height");
        float intensity = jsonLoader.loadFloatFromEvent(eventJson, "force");
        float posX = _slot.position.x;
        float posY = _slot.position.y;
        float directionX = jsonLoader.loadFloatFromEvent(eventJson, "directionX");
        float directionY = jsonLoader.loadFloatFromEvent(eventJson, "directionY");
        Vec2 direction = new Vec2(directionX, directionY);
        forceField = new ForceField(posX, posY, w, h, direction, intensity);
    }

}
/**
 * This is where the actual game part of this game happens. This class manages initiates the active Game object with a player an player particles, handles the execution of game events loaded from event.json and manages a score.
 */
public class Game extends SceneContent
{
    /**
     * A direct reference to the current player object
     */
    private PlayerObject player;

    /**
     * Stores all Events that are currently active
     */
    private ArrayList<GameObjectEvent>activeEvents;

    /**
     * Stores all points in time where events happen as int values and matches * them with an event key. Event keys can than be matched with event data.
     * 
     * @see EventFactory
     */
    private HashMap<Integer, String>eventKeys;

    /**
     * Instance of EventFactroy that creates new Events from an id retrieved 
     * from a value from eventKeys
     *
     * @see eventKeys
     */
    private EventFactory eventFactory;

    /**
     * Stores all Spawning slots of the game
     */
    private Slot[] slots;

    /**
     * Helper variable for setting up the score 
     */
    private int timerStart;

    /**
     * The color of the background
     */
    private int backgroundColor;

    /**
     * The color of the score display
     */
    private int fontColor;

    /**
     * Sets up a new game with a fresh timer and new Particles
     */
    public Game()
    {
        activeEvents = new ArrayList<GameObjectEvent>();
        // Event related stuff
        eventKeys = jsonLoader.loadEventHashMap();
        eventFactory = new EventFactory();
        // load Slots
        slots = jsonLoader.loadSlots();
        // load config data
        backgroundColor = jsonLoader.loadColorFromConfig("background");
        fontColor = jsonLoader.loadColorFromConfig("font");
        // create player Particles and add them to activeObjects
        initiatePlayerParticles();
        // create Player object and add to active objects
        player = new PlayerObject(mouseX, mouseY);
        activeObjects.addObject(player);
        activeObjects.setPlayer(player);
        // initiate score
        scoreManager.resetCurrent();
        timerStart = millis();
    }

    /**
     * Called once every frame. Handles all the game logic:
     * updates Player, game objects, handles individual object type actions. 
     * updates the timer/score and checks if any objects can be deleted
     */
    public void update()
    {
        //update all GameObjects
        activeObjects.update();       
        //Timer and score update
        updateTimer();
        //update Event List and active Events
        checkForEvents();
        for (int i = 0; i < activeEvents.size(); i++) {
            GameObjectEvent event = activeEvents.get(i);
            event.update();
            if (event.hasExpired()) {
                event.markDeletables();
                activeEvents.remove(event);
                i--;
            }
        }
        // check if the game should continue or change to the lost screen
        if (!activeObjects.getParticleAliveness()) {
            changeScene(SceneType.LOST);
            fail.play();
            scoreManager.tryInsertScore(scoreManager.getCurrent());
        }
    }

    /**
     * Called once every frame. Handles all displaying logic.
     */
    public void display()
    {
        background(backgroundColor);
        activeObjects.display();
        displayScore();
    }

    /**
     * Formats and displays the score in the top left corner.
     */
    public void displayScore()
    {
        fill(fontColor);
        textSize(30);
        textAlign(LEFT, TOP);
        text(scoreManager.getCurrent(), 30, 30);
    }

    /**
     * adds the time that has passed since the last frame to the score
     */
    public void updateTimer()
    {
        int deltaTimer = millis() - timerStart;
        scoreManager.setCurrent(deltaTimer / 1000.0f);
    }

    /**
     * Invoked when the scene containing the game is destroyed
     * Destroys and removes all Objeect from activeObjects.
     */
    public void removeExternalLibraryReferences() 
    {
        activeObjects.clearAllObjects();
        activeEvents.clear();
    }

    /**
     * checks the events Hashmap for entries at the current second of the   game's runtime. If one is found and there currently is a free slot available, the matching event is added to active events at that slot and the Hashmap entry is removed.
     */
    private void checkForEvents() 
    {
        int secondValue = (int)scoreManager.getCurrent();
        if (eventKeys.containsKey(secondValue)) {
            String id = eventKeys.get(secondValue);
            // try to assign a free slot
            Slot slot = getRandomFreeSlot();
            if (slot != null) {
                GameObjectEvent event = createEventFromID(id, slot);
                // add event to active events if event was created
                if (event != null) {
                    activeEvents.add(event);
                    // add Event's object to GameObjects
                    if (event.hasObject()) {
                        event.addManagedObjectsToActiveObjects();
                        event.tryAddToEmitters();
                        spawnSound.play();
                    }
                }
            }
            // remove event key from list
            eventKeys.remove(secondValue);
        }
    }

    /**
     * creates and returns a new GameObjectEvent From the given ID
     */
    private GameObjectEvent createEventFromID(String id, Slot slot)
    {
        return eventFactory.createEvent(id, slot);
    }

    /**
     * Collects all slots that are currently not locked by an event and 
     * randomly returns one of them.
     * 
     * @return A Slot that is currently not locked by any event. Null if none is available.
     */
    private Slot getRandomFreeSlot()
    {
        ArrayList<Slot> frees = new ArrayList<Slot>();
        for (int i = 0; i < slots.length; i++) {
            if (!slots[i].isLocked) {
                frees.add(slots[i]);
            }
        }
        if (frees.size() > 0) {
            return frees.get((int)random(0, frees.size() - 1));
        }
        return null;
    }

    /**
     * Initiates the amount of player Particles defined in the configuration
     * and adds them to the active objects.
     * Spawning location is the point on a radius around the mouse that is closest to the center. This avoids that the particles spawn to close too the screen edges already.
     */
    private void initiatePlayerParticles()
    {
        int playerParticleNumber = jsonLoader.loadIntFromConfig("playerParticle", "number");
        float particleRadius = jsonLoader.loadFloatFromConfig("playerParticle", "radius");
        Vec2 particleOrigin = getplayerParticleOrigin();
        for (int i=0; i < playerParticleNumber; i++) {        
            PlayerParticle p = new PlayerParticle(
                mouseX + particleOrigin.x + (float)Math.random(), 
                mouseY + particleOrigin.y + (float)Math.random(), 
                particleRadius);
             activeObjects.addObject(p);
             activeObjects.addPlayerParticle(p);
        }
    }

    /**
     * calculates and returns the spawning point for playerParticles at the 
     * beginning of a game. 
     *
     * @return the point on the radius specified in config.json that lies on the distance between the mouse and the screen center
     */
    private Vec2 getplayerParticleOrigin()
    {
        float originRadius = jsonLoader.loadFloatFromConfig("playerParticle", "originRadius");
        // calculate distance in world measurement first
        Vec2 mouse = box2d.coordPixelsToWorld(mouseX, mouseY);
        Vec2 center = box2d.coordPixelsToWorld(width / 2, height / 2);
        center.subLocal(mouse);
        // convert back to pixels
        Vec2 origin = box2d.coordWorldToPixels(center);
        origin.normalize();
        origin.mulLocal(originRadius);
        return origin;
    }
}
/**
 * The base class for every physical Object in the game.
 */
public abstract class GameObject
{
    /**
     * references the objects Box2d representation 
     */
    protected Body body;

    /**
     * flag that determines if the object should continue to exist in the next frame. if set to false, it will be deleted by the scene in the next frame.
     */
    protected boolean isAlive = true;

    /**
     * true if the object has been actively deleted by the game. 
     * false otherwise. Used only for assertion/ debugging purposes. 
     */
    protected boolean _deleted = false;
    /**
     * will initiate the object with a box2d body with no collider
     * @param posX x coordinate (in pixels) where the object will be initiated
     * @param posY y coordinate (in pixels) where the object will be initiated
     */


    /**
     * Everey Game object is linked to a box2d body and is initiated with a 
     * lifespan. If the lifespan is 
     */
    public GameObject(float posX, float posY)
    {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = getBodyType();
        bodyDef.position.set(box2d.coordPixelsToWorld(posX, posY));
        //assign userdata to get a reference to object in collision callback
        bodyDef.userData = this;
        body = box2d.createBody(bodyDef);
    }

    /**
     * applies a force to the object's body in the box2d world
     * @param force the force to be applied as vector
     */
    public void applyForce(Vec2 force)
    {
        body.applyForce(force, body.getWorldCenter());
    }

    /**
     * @return the object's Body instance in the box2d world
     */
    public Body getBody()
    {
        return body;
    }

    /**
     * called once every frame.
     * updates properties of the object that are not part of the box2d 
     * simulation. Child classes override this method if necessary.
     * Updates the objects lifetime as the most basic function.
     */
    public void update() {}

    /**
     * marks an object as ready for removal
     * invoked during Collision callback
     */
    public void setDead() 
    {
        isAlive = false;
    }

    /**
     * removes the reference to the object from the box2d world and invokes a 
     * custom destroy method for additional cleanup of child classes
     */
    public final void destroy()
    {
        try {
            _destroy();
            box2d.destroyBody(body);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        
    }

    /**
     * space for custom tasks that are executed when a Game object is destroyed
     * only called from within the public destroy method to ensure the box2d 
     * body is always removed on destroy
     */
    protected abstract void _destroy();

    /**
     * checks and returns if the Object is to be removed frome the scene
     * @return true if the object can be removed from the scene, false otherwise
     */
    public abstract boolean checkAliveness();

    /**
     * the object's method to display itself. Called once every frame.
     */
    public abstract void display();

    /**
     * @return either DYNAMIC, STATIC or KINEMATIC depending on the inheriting class
     * used solely by the constructor for the body definition
     */
    protected abstract BodyType getBodyType();

    /**
     * used for debugging and assertion purposes
     * 
     * @return the value of @see _deleted
     */
    public boolean isDeleted() 
    {
        return _deleted;
    }
}
/**
 * This class is the base calss for a wrapper around the spawning of one or more
 * GameObjects in the Game.
 * It contains the GameObjects themselves and manages their behaviour in the 
 * game. Managed properties are the chance of spawning, spawning location, the * objects' lifetime and values the objects are initiated with. The reason for 
 * this aproach is to seperate the GameObject's behaviour within the game flow * from the object logic itself and to allow for better control over the game 
 * flow. Values for all managed parameters are stored in events.json. 
 * Inheriting classes define special managed values and properies for 
 * different kinds of GameObjects.
 */
public abstract class GameObjectEvent
{
    /**
     * Reference to a serialized Data object from events.json
     * This is the source of the event data.
     */
    protected JSONObject eventJson;
    

    /**
     * The event duration aka the lifetime of the managed object
     */
    protected int lifeTime = 0;

    /**
     * Flag that is set to true when the event is past its lifetime and can 
     * be deleted
     */
    protected boolean _hasExpired = false;

    /**
     * Has Information if the event spawned an object.
     */
    protected boolean _hasObject = false;

    /**
     * The slot that is assigned to the event. In program, this is done by the * game.
     */
    protected Slot _slot;

    /**
     * This Flag states if the vent manages a Force Emitter. 
     */
    protected boolean _hasEmitter = false;

    /**
     * Loads Event data from events.json. 
     * Firstly, determines if an object will be spawned at a certain possibility
     * If so, the object associated with the event is created and initiated with
     * values specified in the event data.
     *
     * @param id Id of the json object from wich the event data is loaded
     * @param slot The Slot allocated to the event. Relevant for retrieving position data.
     */
    public GameObjectEvent(String id, Slot slot) {
        eventJson = loadEventJSONObject(id);
        float chance = eventJson.getFloat("chance");
        if (Math.random() <= chance) {
            _hasObject = true;
            _slot = slot;
            int duration = eventJson.getInt("duration");
            lifeTime = millis() + duration;
            createManagedGameObject();
        } else {
            _hasExpired = true;
        }
    } 

    /**
     * invokes the inhertiting classe's custom update function and updates the * timer. Marks the event as expired if lifetime has run out.
     */
    public final void update() {
        int currentLifeTime = lifeTime - millis();
        _update();
        if (currentLifeTime < 0) {
            _hasExpired = true;
        }
    }

    /**
     * gives the game access to the _hasExpired flag
     *
     * @return The value of _hasExpired.
     */
    public boolean hasExpired()
    {
        return _hasExpired;
    }

    /**
     * @return The Value of _hasObject.
     */
    public boolean hasObject() 
    {
        return _hasObject;
    }

    /**
     * @return The Value of _hasEmitter. Called by the game to check if the 
     * event object should be registered as Emitter.
     */
    public boolean hasEmitter()
    {
        return _hasEmitter;
    }

    /**
     * Events with Emitters override this method
     */
    public void tryAddToEmitters() {}

    /**
     * @param id the event's id 
     * 
     * @return The Event's JSON Data from event.json
     */
    protected JSONObject loadEventJSONObject(String id) 
    {
        return jsonLoader.loadEventById(id);
    }



    /**
     * @return The GameObject that the event manages
     */
    protected abstract void createManagedGameObject();

    /**
     * The inheriting classes' custom update method that is called after the 
     * timer update
     */
    protected abstract void _update();

    /**
     * @return the managed GameObject if it exists. Null otherwise.
     */
    //public abstract GameObject getObject();

    /**
     * Marks Objects managed by the Event as dead. This methos is called by a 
     * Game instance on an event when it has expired.
     */
    public abstract void markDeletables();

    /**
     * Adds the managed GameObject(s) to the list of active Game Objects
     */
    public abstract void addManagedObjectsToActiveObjects();
}
/**
 * Displays Highscores. That's it.
 */
public class HighscoreScreen extends SceneContent
{
    private int _fontColor;
    private int _background;
    /**
     * The displayed Score values
     */
    private float[] scores;

    private String controlLine = jsonLoader.loadText("controlLine", "controlLine");

    public HighscoreScreen() {
        _background = jsonLoader.loadColorFromConfig("highscores");
        _fontColor = jsonLoader.loadColorFromConfig("font");
        scores = scoreManager.getHighscoreValuesAsArray();
    }

    public void update() {}
    
    public void display() {
        background(_background);
        fill(_fontColor);
        textSize(70);
        textAlign(LEFT, TOP);
        text("HIGHSCORES", 50, 50);
        displayHighscores();
        textAlign(LEFT, BOTTOM);
        textSize(15);
        text(controlLine, 50, height - 50);
    }

    public void displayHighscores() {
        // formatting
        fill(_fontColor);
        textSize(30);
        textAlign(LEFT, TOP);
        // get score values from score manager
        float[] scores = scoreManager.getHighscoreValuesAsArray();
        for (int i = 0; i < scores.length; i++) {
            int posY = 150 + i * 50;
            int counter = i + 1;
            String value = String.format("%.3f", scores[i]);
            text(counter + ". " + value, 50, posY);
        }
    }

    protected void removeExternalLibraryReferences() {}
}
/**
 * This class provides different methods to load data from the event.json and 
 * config.json files.
 */
public class JSONLoader
{
    /**
    * Reference to the config.json data
    */
    private JSONObject config;

    /**
    * Reference to events.json data. All Game events are loaded from there.
    */
    private JSONObject events;

    /**
     * Reference to eventKeys.json data. 
     * All event - time pairings are stored here.
     */
    private JSONArray eventKeys;
    
    /**
     * Loads the json files config.json and events.json
     */
    public JSONLoader()
    {
        config = loadJSONObject("config.json");
        events = loadJSONObject("events.json");
        eventKeys = loadJSONArray("eventKeys.json");
    }
    
    /**
     * loads the color information from the given JSON object and returns the 
     * equivalent processing color
     * 
     * @param jsonName: The string representation of the json Object from wich * the color should be loaded
     * @return The color with the values from the specified jsonObject. 
     * If there is no such Object in the config, 
     * the default color(255, 255, 255) is returned.
     */
    public int loadColorFromConfig(String jsonName)
    {
        JSONObject json = config.getJSONObject(jsonName);
        if (json != null) {
            JSONObject jsonColor = json.getJSONObject("color");
            int r = jsonColor.getInt("r");
            int g = jsonColor.getInt("g");
            int b = jsonColor.getInt("b");
            return color(r, g, b);
        }
        return color(255, 255, 255);
    }

    /**
     * Loads and returns a float value from an object from config.json   
     *
     * @param jsonObject The JsonObject where the float is loaded from
     * @param forceName The name of the floatto be loaded
     * @return The loaded value. 0.0 if jsonObject does not exist in config
     */
    public float loadFloatFromConfig(String jsonObject, String floatName)
    {
        JSONObject json = config.getJSONObject(jsonObject);
        if (json != null) {
            return(json.getFloat(floatName));
        }
        return 0.0f;
    }

    /**
     * Loads an int value from an object from config.json
     *
     * @param jsonObject The JsonObject where the int is loaded from
     * @param intName The name of the int to be loaded
     * @return The loaded value. 0 if jsonObject does not exist in config
     */
    public int loadIntFromConfig(String jsonObject, String intName)
    {
        JSONObject json = config.getJSONObject(jsonObject);
        if (json != null) {
            return(json.getInt(intName));
        }
        return 0;
    }

    /**
     * Loads and returns json event data for a given second in the game from 
     * the specified category 
     * from events.json. 
     * 
     * @param id the event's id to be loaded
     */
    public JSONObject loadEventById (String id) {
        return events.getJSONObject(id);
    }

    /**
     * @return The eventId - time pairings from eventKeys as Hashmap
     */
    public HashMap<Integer, String> loadEventHashMap()
    {
        HashMap<Integer, String> map = new HashMap<Integer, String>();
        for (int i = 0; i < eventKeys.size(); i++) {
            JSONObject object = eventKeys.getJSONObject(i);
            int key = object.getInt("second");
            String value = object.getString("id");
            map.put(key, value);
        }
        return map;
    }

    /**
     * loads a String from an event JSONObject
     *
     * @param event the JSONObject the String is loaded from
     * @param key The yey to the String value
     * @return a String value
     */
    public String loadStringFromEvent(JSONObject event, String key) 
    {
        return event.getString(key);
    }

    /**
     * loads a float from an event JSONObject
     *
     * @param event the JSONObject the float is loaded from
     * @param key The yey to the float value
     * @return a float value
     */
    public float loadFloatFromEvent(JSONObject event, String key) 
    {
        return event.getFloat(key);
    }

    /**
     * loads an int from an event JSONObject
     *
     * @param event the JSONObject the int is loaded from
     * @param key The yey to the int value
     * @return an int value
     */
    public int loadIntFromEvent(JSONObject event, String key)
    {
        return event.getInt(key);
    }

    /**
     * loads all Data from spawningPositions.json into Slot Objects 
     * and returns them as Array.
     */
    public Slot[] loadSlots()
    {
        JSONArray json = loadJSONArray("spawningPositions.json");
        Slot[] slots = new Slot[json.size()];
        for (int i = 0; i < slots.length; i++) {
            JSONObject slotJson = json.getJSONObject(i);
            String name = slotJson.getString("name");
            // the x and y value from the json data refer to the relative
            // position on Scrren and are therefore multiplied by
            // width and height
            float x = slotJson.getFloat("x") * width;
            float y = slotJson.getFloat("y") * height;
            Vec2 position = new Vec2(x, y);
            slots[i] = new Slot(name, position);
        }
        return slots;
    }

    /**
     * loads the highscore List from highscores.json
     * @return the Highscore Data as List
     */
    public ArrayList<Float> loadHighscoresAsList()
    {
        ArrayList<Float> scores = new ArrayList<Float>();
        JSONArray highscoresJson = loadJSONArray("highscores.json");
        for (int i = 0; i < highscoresJson.size(); i++) {
            JSONObject scoreObject = highscoresJson.getJSONObject(i);
            float value = scoreObject.getFloat("value");
            scores.add(value);
        }
        return scores;
    }

    /**
     * Loads and return a String from texts.json
     */
    public String loadText(String object, String key) {
        JSONObject texts = loadJSONObject("texts.json");
        JSONObject obj = texts.getJSONObject(object);
        String str = obj.getString(key);
        return str;
    }
}
/**
 * A physics based game using the Box2D physics engine
 * @author Franziska Schneider
 * @version 0.1
 * 
 */










/**
 * Minim instance
 */
private Minim minim;

/**
 * Minim audio player for background music
 */
private AudioPlayer player;

/**
 * A spawn sound that is played when a new Object spawns
 */
SoundFile spawnSound;

/**
 * The sound of a pulsar changig mode
 */
SoundFile pulsarChange;

/**
 * The sound that is played when the game is lost
 */
SoundFile fail; 

/**
 * The game's instance of the Box2d Physics engine
 */
private Box2DProcessing box2d;

/**
 * Reference to a utility Object 
 * Providing nice non-static global utility methods for loading json data etc. * Used by multiple classes
 */
private JSONLoader jsonLoader;

/**
 * Score manager instance that provides the ability to share scores across scenes
 */
private ScoreManager scoreManager;

/**
 * All game scenes as Array List
 * @see Scene
 */
private ArrayList<Scene>scenes;

/**
 * The scene currently on display
 * @see scene
 */
private Scene activeScene;

/**
 * Contains and manages all currently active GameObjects
 */
public ActiveGameObjectsManager activeObjects; 


/**
 * Setup size int this function because the console said so
 */
public void settings()
{
    size(1080, 720);
}

/**
 * Initiate the processing sketch and the box2D world and load configuration 
 * data. Also loads and initiates sound data.
 */
public void setup()
{
    // load sound Files
    minim = new Minim(this);
    // Absolutely AWESOME music by Jonas Jestzig
    player = minim.loadFile("sounds/majorTom.mp3");
    player.play();
    spawnSound = new SoundFile(this, "sounds/deepSpawn.wav");
    pulsarChange = new SoundFile(this, "sounds/pulsarchange.mp3");
    fail = new SoundFile(this, "sounds/fail.wav");
    // setup box2d engine
    box2d = new Box2DProcessing(this);
    box2d.createWorld();
    box2d.setGravity(0.0f, 0.1f);
    box2d.listenForCollisions();
    // initiate Serializer
    jsonLoader = new JSONLoader(); 
    scoreManager = new ScoreManager();
    scenes = new ArrayList<Scene>();
    activeScene = new Scene(SceneType.MENU);
    activeObjects = new ActiveGameObjectsManager();
}

/**
 * Update the box2d world and the currently active Scene
 */
public void draw()
{
    box2d.step();
    activeScene.run();
}

/**
 * Called at the Beginning of a Box2d Collision Event.
 * Checks if the two colliding objects have a colliding
 * action and executes it
 */
public void beginContact(Contact cp) 
{
    UserDatas datas = getCollidingObjectsUserData(cp);
    if (datas.getUserData1() != null && 
        datas.getUserData2() != null) {
        //check in both directions
        tryCallOnCollisionEnter(datas.getUserData1(), datas.getUserData2());
        tryCallOnCollisionEnter(datas.getUserData2(), datas.getUserData1());
    } 
}

/**
 * Called at the End of a Box2d Collision Event.
 * Checks if the two colliding objects have a Collision End Action 
 * and executes it
 */
public void endContact(Contact cp) {
    UserDatas datas = getCollidingObjectsUserData(cp);
    if (datas.getUserData1() != null && 
        datas.getUserData2() != null) {
        //check in both directions
        tryCallOnCollisionExit(datas.getUserData1(), datas.getUserData2());
        tryCallOnCollisionExit(datas.getUserData2(), datas.getUserData1());
    }
}

/**
 * assignes the UserData of the two Fixtures involved in contact to o1 and o2 
 *
 * @return 1 if userData from both Fixtures could be assigned, 0 otherwise
 * 
 */
public UserDatas getCollidingObjectsUserData(Contact contact)
{
    Fixture f1 = contact.getFixtureA();
    Fixture f2 = contact.getFixtureB();
    Body b1 = f1.getBody();
    Body b2 = f2.getBody();
    Object o1 = b1.getUserData();
    Object o2 = b2.getUserData();
    return new UserDatas(o1, o2);
}

/**
 * invoked during endContact()
 * checks if o1 implements OnCollisionEnter and calls its method if that 
 * is the case 
 *
 * @param o1 the first Object involved in the collision
 * @param o2 the second object involved in the collision
 */
private void tryCallOnCollisionEnter(Object o1, Object o2)
{
    if (o1 instanceof OnCollisionEnter) {
        OnCollisionEnter collidable = (OnCollisionEnter)o1;
        GameObject collidingThing = (GameObject)o2;
        collidable.onCollisionEnter(collidingThing);
    }
}

/**
 * Invoked during beginContact()
 * checks if o1 implements OnCollisionExit and calls its method if that 
 * is the case 
 *
 * @param o1 the first Object involved in the collision
 * @param o2 the second object involved in the collision
 */
private void tryCallOnCollisionExit(Object o1, Object o2)
{
    if (o1 instanceof OnCollisionExit) {
        OnCollisionExit collidable = (OnCollisionExit)o1;
        GameObject exitingThing = (GameObject)o2;
        collidable.onCollisionExit(exitingThing);
    }
}

/**
 * Processes a key command to switch between scenes.
 */
public void keyPressed() {
    SceneType type = null;
    switch (key) {
        case ENTER:
            type = SceneType.GAME;
            break;
        case 'm':
            type = SceneType.MENU;
            break;
        case 't': 
            type = SceneType.TUTORIAL;
            break;
        case 'h':
            type = SceneType.HIGHSCORE;
    }
    if (type != null) {
        changeScene(type);
    }
}

/**
 * destroys the active Scene and creates a new one
 * 
 * @param type the content type of the new scene
 */
public void changeScene(SceneType type)
{
    if (activeScene != null) {
        activeScene.destroy();
    }
    activeScene = new Scene(type);
}
/**
 * The main menu of the game
 */
public class Menu extends SceneContent
{
    /**
     * A container for beautiful background decoration enhancing the mood of
     * the game. Very design. Yes, they are player particles spawning from a 
     * magic number. I have no regrets.
     */
    private ArrayList<PlayerParticle> particles;

    /**
     * Also a very beautiful little happyLittlePulsar to enhance the mood of the menu even further. In case I forget to delete this before I submit it: Sorry, it was very late and this is the last personal comment in this documentation. I swear.
     */
    private Pulsar happyLittlePulsar;

    private int _background = jsonLoader.loadColorFromConfig("background");
    private PFont font;
    private int fontColor;
    // load texts
    private String title = jsonLoader.loadText("menu", "title");
    private String subtitle = jsonLoader.loadText("menu", "subtitle");
    private String controls = jsonLoader.loadText("menu", "controls");

    public Menu() 
    {
        
        // Telegrama font by Yamaoka Yashuhiro, 1992
        font = createFont("fonts/telegrama_raw.otf", 20);
        textFont(font);
        fontColor = jsonLoader.loadColorFromConfig("font");
        // fill with lovely particles
        particles = new ArrayList<PlayerParticle>();
        for (int i = 0; i < 180; i++) {
            particles.add(new PlayerParticle(
                random(0, width),
                random(0, height),
                3
            ));
        }
        happyLittlePulsar = new Pulsar(width / 2, height / 2, 30, false, 50); 
    }
    public void update()
    {
        happyLittlePulsar.update();
        for (PlayerParticle particle: particles) {
            Vec2 force = happyLittlePulsar.emitForce(particle);
            particle.applyForce(force);
            particle.update();
        }
    }

    public void display()
    {
        background(_background);
        happyLittlePulsar.display();
        // display particles
        for (PlayerParticle particle: particles) {
            particle.display();
        }
        displayText();
    }

    /**
     * Formats and displays all the text
     */
    public void displayText()
    {
        fill(fontColor);
        textAlign(LEFT, TOP);
        textSize(70);
        text(title, 50, 50);
        textSize(20);
        text(subtitle, 50, 130);
        textAlign(LEFT, BOTTOM);
        textSize(30);
        text(controls, 50, height - 50);
    }

    protected void removeExternalLibraryReferences() {
        for (PlayerParticle particle: particles) {
            particle.destroy();
        }
        particles.clear();
        happyLittlePulsar.destroy();
    }
}
/**
 * implemented by Game Objects that have a special action on collision with 
 * other game objects
 */
public interface OnCollisionEnter 
{
    /**
     * special action of game object goes here
     * 
     * @param collider the object this object is collising with
     */
    public void onCollisionEnter(GameObject collider);
}
/**
 * implemented by Game Objects with actions that happen after
 */
public interface OnCollisionExit
{
    /**
     * invoked by the endContact() Method
     * @param collider the other object involved in the ending collision
     */
    public void onCollisionExit(GameObject collider);
}
/**
 * Game Objects subjected to all forces that are created in huge numbers
 */
public abstract class Particle extends GameObject
{
    /**
     * the particle's radius
     */
    private float _radius;

    /**
     * the particle's color
     */
    protected int _color = color(252, 3, 227);

    
    /**
     * @param posX x coordinate (in pixels) where the object will be initiated
     * @param posY y coordinate (in pixels) where the object will be initiated
     * @param radius radius of the default visual representation and circular *        shape
     */
    public Particle(float posX, float posY, float radius)
    {
        super(posX, posY);
        body.setLinearDamping(0.1f);
        _radius = radius;
        CircleShape shape = new CircleShape();
        float worldRadius = box2d.scalarPixelsToWorld(_radius);
        shape.m_radius = worldRadius;

        FixtureDef fixDef = new FixtureDef();
        fixDef.shape = shape;
        fixDef.friction = 0.5f;
        fixDef.restitution = 0.1f;
        fixDef.density = 50;

        body.createFixture(fixDef);
    }

    public void display()
    {
        Vec2 position = box2d.getBodyPixelCoord(body);
        push();
            noStroke();
            fill(_color);
            ellipse(position.x, position.y, _radius * 2, _radius * 2);
        pop();
    }

    /**
     * checks and returns if the Object is to be removed frome the scene
     * @return false if the object is outside the visible screen 
     * or marked as dead, true otherwise
     */
    public boolean checkAliveness() 
    {
        if (!isAlive) return false;
        Vec2 position = box2d.getBodyPixelCoord(body);
        if (position.x < -50 || position.x > width + 50) return false;
        if (position.y < -50 || position.y > height + 50) return false;
        return true;
    }

    protected void _destroy()
    {
        _deleted = true;
    }

    /**
     * @return BodyType.DYNAMIC as particles are dynamic objects
     */
    protected BodyType getBodyType()
    {
        return BodyType.DYNAMIC;
    }

    
}

/**
 * Dynamic objects with variable shape that are subject to forces and can 
 * collide with other objects but 
 * have no interaction upon collision
 */
public abstract class PassiveObject extends GameObject
{
    public Vec2 _velocityImpulse;

    public PassiveObject(float x, float y, Vec2 velocityImpulse) {
        super(x, y);
        _velocityImpulse = velocityImpulse;
    }

    public abstract void display();
    public void update() {}

    /**
     * @return false if the object is either already marked as dead more than 
     * 50 pixels out of the screen
     */
    public boolean checkAliveness() {
        if (!isAlive) return false;
        Vec2 position = box2d.getBodyPixelCoord(body);
        if (position.x < -50 || position.x > width + 50) {
            isAlive = false;
            return false;
        }    
        if (position.y < -50 || position.y > height + 50) {
            isAlive = false;
            return false;
        }  
        return true;
    }

    protected void _destroy() {}

    /**
     * overrides the default return of BodyType.STATIC
     */
    protected BodyType getBodyType() 
    {
        return BodyType.DYNAMIC;
    }

    /**
     * @return the object's instance of Box2d.Shape
     */
    protected abstract Shape getShape();

    /**
     * sets up shape and fixture of the object. Called by the constructors of 
     * inheriting classes after variables needed for the execution of 
     * getShape() have been initiated
     */
    protected void bindFixtureProperties() 
    {
        Shape shape = getShape();

        FixtureDef fixDef = new FixtureDef();
        fixDef.shape = shape;
        fixDef.friction = 0;
        fixDef.restitution = 0.1f;
        fixDef.density = 10000;
        Vec2 force = _velocityImpulse.mulLocal(fixDef.density);

        body.createFixture(fixDef);
        body.applyLinearImpulse(force, body.getWorldCenter(), false);
    }
}
public class PlayerObject extends BlackHole
{
    private float _attractionMultiplier;
    
    public PlayerObject(float posX, float posY) 
    {
        super(posX, 
            posY, 
            jsonLoader.loadFloatFromConfig("player", "radius"), 
            jsonLoader.loadFloatFromConfig("player", "attraction")
        );
        _color = jsonLoader.loadColorFromConfig("player");
        _attractionMultiplier = jsonLoader.loadFloatFromConfig("player", "attractionMultiplier");
    }

    /**
     * the player object steered by a constant strong attracting force in the  
     * direction of the mouse
     */
    public void update()
    {
        Vec2 velocity = getMouseAttraction();
        body.setLinearVelocity(velocity);
    }

    /**
     * sets the objects position to the coordinates given as arguments
     * @param x the x coordinate in pixels
     * @param y the y coordinate in pixels
     */
    public void updatePosition(float x, float y)
    {
        body.setTransform(box2d.coordPixelsToWorld(x, y), 0);
    }

    /**
     * overrides the default return of STATIC
     */
    protected BodyType getBodyType()
    {
        return BodyType.KINEMATIC;
    }

    /**
     * calculates the attraction to the mouse proportional to the distance 
     * between object center and mouse position
     * @return the object's velocity as Vec2 pointing from object center to the 
     * mouse position
     */
    private Vec2 getMouseAttraction()
    {
        Vec2 position = body.getWorldCenter();
        Vec2 mouse = box2d.coordPixelsToWorld(mouseX, mouseY);
        mouse.subLocal(position);
        float difference = mouse.length();
        mouse.normalize();
        mouse.mulLocal(difference * _attractionMultiplier);
        return mouse;
    }
}
/**
 * class for the particles the player must protect in the game
 */
public class PlayerParticle extends Particle
{
    
    /**
     * @param posX the x coordinate of the particle's center in pixels
     * @param posY the y coordinate of the particle's center in pixels
     * @param radius the particle's radius
     */
    public PlayerParticle(float posX, float posY, float radius)
    {
        super(posX, posY, radius);
        _color = jsonLoader.loadColorFromConfig("playerParticle");
        // damp the particles a little so they don't become too uncontrollable
        float damping = jsonLoader.loadFloatFromConfig("playerParticle", "damping");
        body.setLinearDamping(damping);
    }

    public void applyPlayerAttraction(PlayerObject player) 
    {
        Vec2 playerForce = player.emitForce(this);
        applyForce(playerForce);
    }
}
/**
 * A force emitting static game object that frequently switches between 
 * attracting and repelling force
 */
public class Pulsar extends CosmicBody
{
    /**
     * the color in which the pulsar is rendered when in attracting mode
     */
    private int _attractColor;
    /**
     * the color in which the pulsar is displayed when in repelling mode
     */

    private int _repelColor;

    /**
     * stores the value of millis() at the time of object creation
     * + the timer duration of 5000 milliseconds
     */
    private int _timerStart;
    
    /**
     * @param posX the x coordinate of the pulsar's center in pixels
     * @param posY the y coordinate of the pulsar's center in pixels
     * @param radius the pulsar's radius
     * @param mode determines whether the pulsar starts attracting or repelling
     * @param g the strength of the force emitted by the pulsar
     */
    public Pulsar(float posX, float posY, float radius, boolean mode, float g)
    {
        super(posX, posY, radius, mode, g);
        _attractColor = jsonLoader.loadColorFromConfig("pulsarDefault");
        _repelColor = jsonLoader.loadColorFromConfig("pulsarRepelling");
        _color = isRepelling ? _repelColor : _attractColor;
        int timerValue = jsonLoader.loadIntFromConfig("pulsarRepelling", "timer");
        _timerStart = millis() + 5000;
    }

    /**
     * toggles the isRepelling flag
     */
    public void toggle()
    {
        isRepelling = !isRepelling;
        _color = isRepelling ? _repelColor : _attractColor;
        pulsarChange.play();
    }

    /**
     * updates the pulsar's countdown timer. after every 5 seconds it will 
     * toggle its mode and reset the timer.
     */
    public void update() 
    {
        int currentTimer = updateTimer();
        if (currentTimer <= 0) {
            toggle();
            resetTimer();
        }
    }

    /**
     * updates the countdown timer by the time passed since the last call.
     * Invoked once per frame.
     *
     * @return the time passed since the last call of updateTimer() in milliseconds
     */
    public int updateTimer ()
    {
        return _timerStart - millis();
    }

    /**
     * resets the timer to 5000 milliseconds
     */
    public void resetTimer()
    {
        _timerStart = millis() + 5000;
    }
}
/**
 * a logically enclosed part of the program such as Menu, Main game etc.
 * This class works as a wrapper around the actual scene content to provide the * main program with a controlled interface for the interaction with 
 * the scene content.
 */
public class Scene
{
    /**
     * references the actual scene content
     */
    private SceneContent content;

    /**
     * For an overview over all content types: @see SceneType
     *
     * @param contentType determines the content of the scene. 
     * @see SceneType
     */
    public Scene(SceneType contentType)
    {
        SceneContentFactory factory = new SceneContentFactory();
        content = factory.getSceneContent(contentType);
        assert content != null;
    }

    /**
     * Will cause the scene Content to update and display itself.
     * Called once per frame.
     */
    public void run()
    {
        content.update();
        content.display();
    }

    /**
     * Will 'clean up' the scene content before the scene is destroyed.
     * Deletes all Objects that are not removied automatically such as 
     * box2d bodies
     */
    public void destroy()
    {
        content.clear();
    }
}
/**
 * base class for actual implementations scene content enforcing the 
 * implementation of update, display and removal of box2d-references.
 */
public abstract class SceneContent 
{
    public abstract void update();
    public abstract void display();
    protected abstract void removeExternalLibraryReferences();
    
    /**
     * removes all references to objects from external Libraries including 
     * box2d and ip5
     * called upon destruction of a scene
     */
    public void clear ()
    {
        removeExternalLibraryReferences();
    }


}
/**
 * Abstract Factory that creates a new instance of Scene Content
 * @see SceneType
 */
public class SceneContentFactory
{
    /**
     * @param type the type of content to be created
     * @return a new instance of the class mapped to the given scene type
     */
    public SceneContent getSceneContent(SceneType type)
    {
        switch (type) {
            case UNSET:
                return null;
            case MENU:
                return new Menu();
            case GAME:
                return new Game();
            case TUTORIAL:
                return new Tutorial();
            case LOST:
                return new LostScreen();
            case HIGHSCORE:
                return new HighscoreScreen();
        }
        return null;
    }
}
/**
 * The set of parameter values for the getSceneContent() method of 
 * SceneContentFactory
 * @see SceneContentFactory
 * @see SceneContent
 */
public enum SceneType
{
    UNSET,
    MENU,
    TUTORIAL,
    GAME,
    HIGHSCORE,
    LOST
}
/**
 * A class for managing score and highscore data accross scenes
 */
public class ScoreManager {
    /**
     * The most recent score that was achieved in the runtime
     */
    private float _currentScore = 0;

    /**
     * A lIst storing all highscores
     */
    private ArrayList<Float> highScores = new ArrayList<Float>();
    
    /**
     * The maximum length of the highscores list
     */
    private int maxEntries;

    public ScoreManager()
    {
        maxEntries = jsonLoader.loadIntFromConfig("highscores", "maxEntries");
        loadHighscores();
    }

    /**
     * @return The value of _currentScore
     */
    public float getCurrent()
    {
        return _currentScore;
    }

    public void setCurrent(float value) {
        _currentScore = value;
        
    }

    /**
     * Sets _currentScore back to 0. Invoked when a new Game is started.
     */
    public void resetCurrent()
    {
        _currentScore = 0;
    }

    /**
     * load saved highscores
     */
    public void loadHighscores() 
    {
        highScores = jsonLoader.loadHighscoresAsList();
        // bring list in reverse Order
        Collections.sort(highScores);
        Collections.reverse(highScores);
    }

    /**
     * returns HighScore float Values as Array
     */
    public float[] getHighscoreValuesAsArray()
    {
        float[] values = new float[highScores.size()];
        for (int i = 0; i < highScores.size(); i++) {
            values[i] = highScores.get(i).floatValue();
        }
        return values;
    }

    /**
     * Checks if the given value is higher than at least one existing Highscore entry. if that is the case, it will be added and the lowest entry will be removed instead. The new Highscore list is then serialized.
     *
     * @param score The score value to be checked for insertion
     */
    public void tryInsertScore(float score) 
    {
        for (int i = 0; i < highScores.size(); i++) {
            if (score > highScores.get(i).floatValue()) {
                highScores.add(i, score);
                break;
            }
        }
        if (highScores.size() > maxEntries) {
            highScores.remove(highScores.size() - 1);
        }
        updateSerialzedHighscores();
    }

    /**
     * writes the current Highscores List back to highscores.json
     */
    private void updateSerialzedHighscores() {
        // serialize and save the data
        JSONArray serializedHighscores = new JSONArray();
        for(int i = 0; i < highScores.size(); i++) {
            JSONObject scoreObject = new JSONObject();
            scoreObject.setFloat("value", highScores.get(i).floatValue());
            serializedHighscores.setJSONObject(i, scoreObject);
        }
        saveJSONArray(serializedHighscores, "data/highscores.json");
    }       


}
/**
 * A container for information about a spawning area in the game.
 * A slot is a specified position on the Screen where Objects can spawn.
 * In a game, one slot can only be occupied by one object at a time.
 */
public class Slot
{
    public Vec2 position;
    public boolean isLocked = false;
    private String _name;

    public Slot(String name, Vec2 pos)
    {
        _name = name;
        position = pos;
    }

    public String getName() 
    {
        return _name;
    }
}
/**
 * Rectangular passive object with angular motion
 */
public class SpaceJunk extends PassiveObject
{
    private float _w;
    private float _h;
    private int _color;

    /**
     * @param x The x coordinate of the object in pixels
     * @param y The y coordinate of the object in pixels
     * @param w The object's width in pixels
     * @param h The object's height in pixels
     */
    public SpaceJunk(float x, float y, float w, float h, Vec2 velocity) 
    {
        super(x, y, velocity);
        _w = w;
        _h = h;
        _color = jsonLoader.loadColorFromConfig("spaceJunk");
        int angularVelocity = jsonLoader.loadIntFromConfig("spaceJunk", "angularVelocity");
        body.setAngularVelocity(angularVelocity);
        body.setFixedRotation(true);
        bindFixtureProperties();
    }

    public void display()
    {
        Vec2 position = box2d.getBodyPixelCoord(body);
        float angle = body.getAngle();
        push();
            noStroke();
            fill(_color);
            translate(position.x, position.y);
            rotate(angle);
            rectMode(CENTER);
            rect(0, 0, _w, _h);
        pop();
    }

    /**
     * @return a rectangular PolygonShape with width w and height h
     */
    protected Shape getShape()
    {
        PolygonShape shape = new PolygonShape();
        float boxWidth = box2d.scalarPixelsToWorld(_w / 2);
        float boxHeight = box2d.scalarPixelsToWorld(_h / 2);
        shape.setAsBox(boxWidth, boxHeight);
        return shape;
    }
}
/**
 * Manages the appearance of multiple SpaceJunk Objects in the Game.
 * Instances of this class don't control the lifespan of 
 * their managed SpaceJunk Objects,
 * meaning they don't get deleted after a fixed timespan.
 * The event simply spawns them at a location determined by the json data 
 * (with some random factor) and initiates their original impulse towards the 
 * center of the screen. Afterwards, the event's control over the junk ends.
 */
public class SpaceJunkEvent extends GameObjectEvent
{
    
    /**
     * Contains all SpaceJunk objects that are spawned by the event
     */
    private ArrayList<SpaceJunk> junkObjects;
    
    public SpaceJunkEvent(String id, Slot slot)
    {
        super(id, slot);
    }

    /**
     * Adds all managed SpaceJunk Objects to activeObjects
     */
    public void addManagedObjectsToActiveObjects()
    {
        for (SpaceJunk junk: junkObjects) {
            activeObjects.addObject(junk);
        }
    }

    /**
     * Because SpaceJunk events don't manage the lifetime 
     * of their objects, they don't get marked as deletable
     * on expiration here. 
     * (Refactor time-dependent object events into subclass?)
     */
    public void markDeletables() {}

    protected void _update() {}

    /**
     * creates several SpaceJunk Objects from the event json data and adds them 
     * junkObjects
     */
    protected void createManagedGameObject()
    {
        junkObjects = new ArrayList<SpaceJunk>();
        int counter = jsonLoader.loadIntFromEvent(eventJson, "counter");
        for (int i = 0; i < counter; i++) {
            //load json data and add some variance
            float w = jsonLoader.loadFloatFromEvent(eventJson, "width") + random(-10, 10) ;
            float h = jsonLoader.loadFloatFromEvent(eventJson, "height");
            String coordinate = jsonLoader.loadStringFromEvent(eventJson, "slotCoordinate");
            float x;
            float y;
            // determine from which of the four sides the object will spawn
            if (coordinate.equals("x")) {
                //object will spawn from top or bottom of the screen
                x = random(0, width);
                // determines wheter it will top or bottom with 50% chance
                // y is outside the screen
                if (Math.random() < 0.5f) {
                    y = -30;
                } else {
                    y = height + 30;
                }
            }
            else if (coordinate.equals("y")) {
                // object will spawm from left or right
                y = random(0, height);
                // determine wheter it will be left or right with 50% chance
                if (Math.random() < 0.5f) {
                    x = -20;
                } else {
                    x = height + 20;
                }
                // x origin is outside the screen
            } else {
                //if there is an error on the json data
                x = -20;
                y = -20;
            }
            Vec2 position = box2d.coordPixelsToWorld(x, y);
            Vec2 velocity = computeVelocity(position);
            // add new Object 
            SpaceJunk object = new SpaceJunk(x, y, w, h, velocity);
            junkObjects.add(object);
        }
    }

    /**
     * Calculates and returns a vector that is directed from the position given * in the parameter to the center of the screen. Used to get the impulse 
     * for newly created SpaceJunk objects.
     *
     * @param position The position of the object in the box2d world for which the velocity is calculated
     * @return a Vector directed at the center of the screen with variance
     */
    private Vec2 computeVelocity(Vec2 position)
    {
        float speed = jsonLoader.loadFloatFromEvent(eventJson, "speed") + random (-10, 10);
        float directionX = width / 2 + random(-10, 10);
        float directionY = height / 2 + random(-10, 10);
        Vec2 direction = box2d.coordPixelsToWorld(directionX, directionY);
        direction.subLocal(position);
        direction.normalize();
        direction.mulLocal(speed);
        return direction;
    }
}
/**
 * The "How to play section" showing explaining the different objects.
 * The objects are just for visualization, meaning that they don't show their full behaviour
 */
public class Tutorial extends SceneContent 
{    
    private int _background = jsonLoader.loadColorFromConfig("background");
    private String starControl = jsonLoader.loadText("tutorial", "control");
    private String blackHoleControl = jsonLoader.loadText("tutorial", "blackHole");
    private String forceFieldControl  = jsonLoader.loadText("tutorial", "forceField");
    private String antiMatterControl = jsonLoader.loadText("tutorial", "antiMatter");
    private String pulsarControl = jsonLoader.loadText("tutorial", "pulsar");
    private String spaceJunkControl = jsonLoader.loadText("tutorial", "spaceJunk");
    private String controlLine = jsonLoader.loadText("controlLine", "controlLine");
    // Example Objects
    private Pulsar pulsar = new Pulsar(700, 330, 20, true, 100);
    private BlackHole blackHole = new BlackHole(200, 330, 20, 100);
    private SpaceJunk junk = new SpaceJunk(180, 530, 50, 10, new Vec2(0, 0));
    private ForceField forceField = new ForceField(700, 500, 310, 80, new Vec2(0,0), 0);
    private ArrayList<Particle> particles = new ArrayList<Particle>();
    private PlayerObject star = new PlayerObject(mouseX, mouseY);

    public Tutorial() 
    {
        // ads all the objects to activeObjects
        activeObjects.addObject(pulsar);
        activeObjects.addObject(blackHole);
        activeObjects.addObject(junk);
        activeObjects.addObject(forceField);
        for (int i = 0; i < 30; i++) {
            activeObjects.addObject(new AntiMatterParticle(random(60, 200), random(630, 700), 3, new Vec2(1, 0), 0.01f));
        }
        for (int i = 0; i < 30; i++) {
            PlayerParticle p = new PlayerParticle(random(30, 80), random(30, 80), 3);
            activeObjects.addObject(p);
            activeObjects.addPlayerParticle(p);
        }
        activeObjects.addObject(star);
        activeObjects.setPlayer(star);
    }

    public void update() {
        // update game Objects
        activeObjects.update();
    }

    public void display() {
        background(_background);
        fill(255);
        textAlign(LEFT, TOP);
        textSize(20);
        text(starControl, 50, 100);
        // individual objects
        // black hole
        text(blackHoleControl, 50, 200);
        // space junk
        text(spaceJunkControl, 50, 400);
        // antimatter
        text(antiMatterControl, 50, 600);
        
        // pulsar
        text(pulsarControl, width / 2, 200);
        // force Field
        text(forceFieldControl, width / 2, 400);
        
        
        // control Line
        textAlign(LEFT, BOTTOM);
        textSize(15);
        text(controlLine, 50, 50);

        //objects
        activeObjects.display();
    }

    protected void removeExternalLibraryReferences() {
        activeObjects.clearAllObjects();
    }
}
/**
 *
 */
public class UserDatas
{
    private Object _userData1;
    public Object getUserData1(){return _userData1;}
    private Object _userData2;
    public Object getUserData2(){return _userData2;}

    public UserDatas(Object userData1, Object userData2)
    {
        _userData1 = userData1;
        _userData2 = userData2;
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "matter_matters" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
